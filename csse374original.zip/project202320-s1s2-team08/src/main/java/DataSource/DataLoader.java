package DataSource;

public interface DataLoader {
    public byte[] loadFileBytes(String name);
}
