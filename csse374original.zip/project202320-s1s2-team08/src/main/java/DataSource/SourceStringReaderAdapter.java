package DataSource;

import java.io.File;

public abstract class SourceStringReaderAdapter {
    public abstract void generateImage(String source, File outputFile);
}
