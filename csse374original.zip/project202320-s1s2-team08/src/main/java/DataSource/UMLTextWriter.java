package DataSource;

public interface UMLTextWriter {
    public void writeUMLText(String filepath, String umltext);
}
