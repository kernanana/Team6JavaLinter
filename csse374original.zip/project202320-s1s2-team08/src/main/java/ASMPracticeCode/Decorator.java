package ASMPracticeCode;

public abstract class Decorator extends AbstractClass{
    private AbstractClass abstractClass;
}
