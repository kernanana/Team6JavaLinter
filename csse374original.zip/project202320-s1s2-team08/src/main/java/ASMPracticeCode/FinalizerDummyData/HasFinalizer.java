package ASMPracticeCode.FinalizerDummyData;

public class HasFinalizer {
    protected void finalize(){

    }
}
