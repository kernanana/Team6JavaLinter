package ASMPracticeCode.FinalizerDummyData;

public class HasFinalizerParams {
    public void finalize(int num) {

    }
}
