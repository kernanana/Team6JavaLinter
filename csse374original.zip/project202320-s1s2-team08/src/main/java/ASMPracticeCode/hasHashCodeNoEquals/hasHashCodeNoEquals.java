package ASMPracticeCode.hasHashCodeNoEquals;

public class hasHashCodeNoEquals {

    @Override
    public int hashCode(){
        return 1;
    }
}
