package ASMPracticeCode;

public class ConcreteClass2 extends AbstractClass {

    @Override
    public int primitiveOperation1() {
        return 1;
    }

    @Override
    public int primitiveOperation2() {
        return 1;
    }

    public boolean equals(Object o){
        return true;
    }
}
