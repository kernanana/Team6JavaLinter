package ASMPracticeCode.DecoratorPatternDoesntHaveInstance;

public abstract class Decorator extends Decorated {
}
