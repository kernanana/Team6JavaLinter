package ASMPracticeCode.DecoratorPatternDoesntHaveInstance;

public abstract class Decorated {
}
