package ASMPracticeCode.hasEqualsNoHashCode;

public class hasEqualsNoHashCode {
    @Override
    public boolean equals(Object o){
        return false;
    }
}
