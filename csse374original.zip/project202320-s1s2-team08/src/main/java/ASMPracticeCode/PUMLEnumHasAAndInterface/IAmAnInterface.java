package ASMPracticeCode.PUMLEnumHasAAndInterface;

public interface IAmAnInterface {
}
