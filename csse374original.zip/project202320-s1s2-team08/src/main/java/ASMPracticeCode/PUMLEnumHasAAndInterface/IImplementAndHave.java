package ASMPracticeCode.PUMLEnumHasAAndInterface;

public class IImplementAndHave implements IAmAnInterface{
    private IAmAnEnum myEnumAndPrivateFields;
    public String iAmAPublicField;
}
