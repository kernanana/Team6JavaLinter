package ASMPracticeCode.PUMLEnumHasAAndInterface;

public enum IAmAnEnum {
    Im,doing,enummy,stuff
}
