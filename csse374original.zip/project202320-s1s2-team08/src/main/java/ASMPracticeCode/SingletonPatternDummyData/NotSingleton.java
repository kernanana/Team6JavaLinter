package ASMPracticeCode.SingletonPatternDummyData;

public class NotSingleton {
}
