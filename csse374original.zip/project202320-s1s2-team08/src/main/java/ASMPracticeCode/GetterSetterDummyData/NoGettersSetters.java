package ASMPracticeCode.GetterSetterDummyData;

public class NoGettersSetters {
    private int number;
    private String string;

    private int getNumber(){
        number += 3;
        return number;
    }

}
