package ASMPracticeCode.GetterSetterDummyData;

public class DataClass {
    private int number;
    private String string;

    private int getNumber(){
        return number;
    }

    private String getString(){
        return string;
    }
}
