package ASMPracticeCode.GetterSetterDummyData;

public class GetterSetterClass {
    private int number;
    private String string;

    public boolean someCalculation(){
        return true;
    }

    public void setNumber(int n){
        number = n;
    }

    public void setString(String s){
        string = s;
    }

    public int getNumber() {
        return number;
    }

    public String getString(){
        return string;
    }
}
