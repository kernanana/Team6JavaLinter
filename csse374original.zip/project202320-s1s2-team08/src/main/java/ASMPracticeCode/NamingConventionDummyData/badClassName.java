package ASMPracticeCode.NamingConventionDummyData;

public class badClassName {
}
