package ASMPracticeCode.NamingConventionDummyData;

public class EverythingErrorClass {
    private int Field;
    private final String FIeLD1 = "This is wrong";
    private final boolean field_2 = false;
    private double FIELD_3;

    public EverythingErrorClass(){}

    public int Method(){
        return -1;
    }
    public String METHOD_2(){
        return "false";
    }

}
