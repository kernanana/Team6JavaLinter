package ASMPracticeCode.NamingConventionDummyData;

public class FinalsClass {
    private final int FIELD = 1;
    private final String FIELD1 = "This is perfectly okay";
    private final boolean FIELD_2 = true;

    public FinalsClass(){};

}
