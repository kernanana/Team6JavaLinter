package ASMPracticeCode.NamingConventionDummyData;

public class PerfectlyOkayClass {
    private String field;
    private int field1;
    private boolean field_2;

    public PerfectlyOkayClass(){}
    public String method(){
        return "This class perfectly follows Naming Convetions";
    };
    public int method1(){
        return 1;
    }

    public boolean method_2(){
        return true;
    }
}
