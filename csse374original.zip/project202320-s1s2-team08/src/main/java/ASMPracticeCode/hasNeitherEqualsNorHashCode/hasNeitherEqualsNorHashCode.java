package ASMPracticeCode.hasNeitherEqualsNorHashCode;

public class hasNeitherEqualsNorHashCode {
}
