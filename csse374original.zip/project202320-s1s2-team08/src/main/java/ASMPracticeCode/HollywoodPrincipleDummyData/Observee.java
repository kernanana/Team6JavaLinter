package ASMPracticeCode.HollywoodPrincipleDummyData;

public class Observee {
    public void notify1(){

    }
    public void badMethod(){
        Observer obs = new Observer();
        obs.notifyAll1();
    }
}
