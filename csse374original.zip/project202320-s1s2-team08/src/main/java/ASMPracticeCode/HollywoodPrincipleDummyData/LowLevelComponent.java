package ASMPracticeCode.HollywoodPrincipleDummyData;

public class LowLevelComponent extends HighLevelComponent{
    @Override
    public void abstractMethod() {
        super.doSomething();
    }
}
