package ASMPracticeCode.HollywoodPrincipleDummyData;

public class Observer {
    Observee observee = new Observee();
    public void notifyAll1(){
        observee.notify1();
    }
}
