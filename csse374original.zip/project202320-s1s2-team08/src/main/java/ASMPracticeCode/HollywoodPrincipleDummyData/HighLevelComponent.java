package ASMPracticeCode.HollywoodPrincipleDummyData;

public abstract class HighLevelComponent {
    public void doSomething(){

    }

    public abstract void abstractMethod();
}
