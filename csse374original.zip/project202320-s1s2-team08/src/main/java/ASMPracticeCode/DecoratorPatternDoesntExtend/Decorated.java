package ASMPracticeCode.DecoratorPatternDoesntExtend;

public abstract class Decorated {
}
