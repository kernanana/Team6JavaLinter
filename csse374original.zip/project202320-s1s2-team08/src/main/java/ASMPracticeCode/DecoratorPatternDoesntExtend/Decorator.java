package ASMPracticeCode.DecoratorPatternDoesntExtend;

public abstract class Decorator {
    private Decorated decorated;
}
