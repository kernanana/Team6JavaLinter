package ASMPracticeCode.PUMLAbstractClassPrivateAbstractMethodsWithAbstractExtender;

public abstract class AbstractClassPrivateAbstractMethodsWithAbstractExtender {
    public abstract void publicAbstractMethod();

    private boolean privateMethod1(){return false;}

    private String privateMethod2(){return "";}
}
