package ASMPracticeCode.PUMLAbstractClassPrivateAbstractMethodsWithAbstractExtender;

public class ExtendsAbstract extends AbstractClassPrivateAbstractMethodsWithAbstractExtender{
    @Override
    public void publicAbstractMethod() {

    }
}
