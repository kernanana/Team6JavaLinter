package ASMPracticeCode.StrategyDummyData;

public class ConcreteStrategy1 implements StrategyInterface{
    @Override
    public void someMethod() {

    }
}
