package ASMPracticeCode.StrategyDummyData;

public interface StrategyInterface {
    public void someMethod();
}
