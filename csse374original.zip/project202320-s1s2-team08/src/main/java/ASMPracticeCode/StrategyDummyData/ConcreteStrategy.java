package ASMPracticeCode.StrategyDummyData;

public class ConcreteStrategy implements StrategyInterface{
    @Override
    public void someMethod() {

    }
}
