package ASMPracticeCode.hasBothHashCodeAndEquals;

public class hasBothHashCodeAndEquals {
    @Override
    public boolean equals(Object o){
        return false;
    }
    @Override
    public int hashCode(){
        return 1;
    }
}
