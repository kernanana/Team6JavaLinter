package ASMPracticeCode.SingleResponsibilityCheckAllInOne;

public class IHaveTwoPublicMethods {
    public void oneMethod(){}
    public void twoMethod(){}
}
