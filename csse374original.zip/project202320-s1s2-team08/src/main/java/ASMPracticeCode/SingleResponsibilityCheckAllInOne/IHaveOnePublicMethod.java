package ASMPracticeCode.SingleResponsibilityCheckAllInOne;

public class IHaveOnePublicMethod {
    public void oneMethod(){}
}
