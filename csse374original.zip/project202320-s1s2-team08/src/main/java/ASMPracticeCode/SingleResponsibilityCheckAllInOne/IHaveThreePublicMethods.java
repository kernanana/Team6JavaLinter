package ASMPracticeCode.SingleResponsibilityCheckAllInOne;

public class IHaveThreePublicMethods {
    public void oneMethod(){}
    public void twoMethod(){}
    public void threeMethod(){}
}
