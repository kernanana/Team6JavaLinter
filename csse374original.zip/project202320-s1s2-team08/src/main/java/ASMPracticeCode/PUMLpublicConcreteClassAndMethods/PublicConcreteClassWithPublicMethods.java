package ASMPracticeCode.PUMLpublicConcreteClassAndMethods;

public class PublicConcreteClassWithPublicMethods {
    public void method1(){}

    public boolean method2(){return false;}

    public String method3(){return "";}
}
