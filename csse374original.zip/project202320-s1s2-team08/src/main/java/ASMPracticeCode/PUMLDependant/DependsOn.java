package ASMPracticeCode.PUMLDependant;

public class DependsOn {
    private void dependsOn(Dependency1 depenencyInArg){}
    private Dependency2 dependsOn2(){
        return new Dependency2();
    }
}
