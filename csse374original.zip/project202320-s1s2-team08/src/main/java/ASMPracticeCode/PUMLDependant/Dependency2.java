package ASMPracticeCode.PUMLDependant;

public class Dependency2 {
}
