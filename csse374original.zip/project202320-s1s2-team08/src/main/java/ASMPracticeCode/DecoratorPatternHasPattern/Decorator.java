package ASMPracticeCode.DecoratorPatternHasPattern;

public abstract class Decorator extends Decorated{
    private Decorated decorated;
}
