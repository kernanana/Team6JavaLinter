package ASMPracticeCode.DecoratorPatternHasPattern;

public abstract class Decorated {
}
