package ASMPracticeCode.SingleResponsibilityCheckPrivateMethods;

public class AllMyMethodsArePrivate {
    private void privateMethod(){}
    private void privateMethod2(){}
}
