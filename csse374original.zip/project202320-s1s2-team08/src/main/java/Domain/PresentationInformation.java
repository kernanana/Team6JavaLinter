package Domain;

import java.util.List;

public class PresentationInformation {
    public boolean passed;
    public CheckType checkName;
    public List<String> displayLines;
}
