package Domain;

public class UserOptions {
    public int maximumMethods;
    public String umlOutputDirectory;
    public boolean parseUml;
    public boolean namingConventionAutoCorrect = false;
}
